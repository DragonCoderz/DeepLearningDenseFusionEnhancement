version https://git-lfs.github.com/spec/v1
oid sha256:42ba0dcbff8210ed44ffb5f26bbff0e8024bc9d1943e0cd7c6b27301adeefa2e
size 13268
