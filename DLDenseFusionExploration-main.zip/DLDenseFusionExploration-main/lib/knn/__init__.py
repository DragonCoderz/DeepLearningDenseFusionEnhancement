version https://git-lfs.github.com/spec/v1
oid sha256:2f87589ed2b38e9b1401c759b62d0d6caaad82b7e1d35f380c8ffbf88c7ffcb1
size 2406
